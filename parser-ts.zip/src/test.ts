import { KrishaApartment } from './domains/krisha-apartment';

async function main(){
    console.log();
}
main();